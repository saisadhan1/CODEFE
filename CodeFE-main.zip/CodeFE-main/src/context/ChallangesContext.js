import React from "react";

const ChallangesContext = React.createContext();

export default ChallangesContext;